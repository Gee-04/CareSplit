// RemitSafe — React 18 UMD + htm (no build step)
// Rules followed throughout:
//   - class= not className=
//   - All conditionals use ternary (? : null) never &&
//   - No nested backtick template literals inside html``
//   - Every component returns html`` or null, never undefined
const { useState, useEffect } = React;
const html = htm.bind(React.createElement);

// ── API helpers ───────────────────────────────────────────────────────────────
function apiCall(path, opts) {
  opts = opts || {};
  var headers = opts.headers || {};
  var token = opts.token
    || localStorage.getItem('authToken')
    || localStorage.getItem('storeToken');
  if (token) headers['Authorization'] = 'Bearer ' + token;
  return fetch(path, Object.assign({}, opts, { headers: headers }))
    .then(function(r) {
      return r.json().catch(function() { return {}; }).then(function(body) {
        return { ok: r.ok, status: r.status, body: body };
      });
    });
}
function sApi(path, opts) {
  opts = opts || {};
  opts.token = localStorage.getItem('authToken');
  return apiCall(path, opts);
}
function tApi(path, opts) {
  opts = opts || {};
  opts.token = localStorage.getItem('storeToken');
  return apiCall(path, opts);
}

// ── Tiny helpers ──────────────────────────────────────────────────────────────
function statusClass(s) {
  if (s === 'FUNDED' || s === 'PARTIALLY_SPENT') return 'badge-green';
  if (s === 'PENDING_FUNDING') return 'badge-amber';
  if (s === 'EXHAUSTED') return 'badge-indigo';
  return 'badge-grey';
}

// ── CopyBtn ───────────────────────────────────────────────────────────────────
function CopyBtn(props) {
  var text = props.text;
  var _s = useState(false);
  var copied = _s[0]; var setCopied = _s[1];
  function doCopy() {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(function() {
        setCopied(true);
        setTimeout(function() { setCopied(false); }, 1800);
      });
    }
  }
  return html`<button class="btn btn-ghost btn-sm" onClick=${doCopy}>${copied ? '✅ Copied' : '📋 Copy'}</button>`;
}

// ── PurchaseHistory ───────────────────────────────────────────────────────────
function PurchaseHistory(props) {
  var history = props.history;
  if (!history || history.length === 0) return null;
  return html`
    <div>
      ${history.map(function(h, i) {
        var icon = h.status === 'COMPLETED' ? '✅' : '❌';
        var amtClass = h.status === 'COMPLETED' ? 'tx-amt-red' : 'tx-amt-red';
        var detail = h.status + (h.rejectedReason ? ' · ' + h.rejectedReason : '');
        var dateStr = h.createdAt ? new Date(h.createdAt).toLocaleString() : '';
        return html`
          <div key=${i} class="tx-item">
            <div class="tx-left">
              <div class=${h.status === 'COMPLETED' ? 'tx-icon tx-icon-green' : 'tx-icon tx-icon-red'}>${icon}</div>
              <div>
                <div class="tx-name">${h.category}</div>
                <div class="tx-cat">${detail}</div>
                ${dateStr ? html`<div class="tx-cat">${dateStr}</div>` : null}
              </div>
            </div>
            <div class=${'tx-amt ' + amtClass}>${h.amount}</div>
          </div>`;
      })}
    </div>`;
}

// ── RefCard ───────────────────────────────────────────────────────────────────
function RefCard(props) {
  var data = props.data;
  var _o = useState(false);
  var open = _o[0]; var setOpen = _o[1];
  if (!data) return null;
  var sc = statusClass(data.status);
  var cats = (data.allowedCategories && data.allowedCategories.length > 0)
    ? data.allowedCategories.join(', ') : null;
  var expiry = data.expiresAt ? new Date(data.expiresAt).toLocaleDateString() : null;
  var histCount = data.history ? data.history.length : 0;
  var toggleLabel = (open ? '▲ Hide' : '▼ Show') + ' purchases (' + histCount + ')';
  return html`
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px">
        <div>
          <div style="font:600 11px/1 var(--body);color:var(--text3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">Reference</div>
          <div class="ref-number">${data.reference}</div>
        </div>
        <${CopyBtn} text=${data.reference} />
      </div>
      <div class="big-amount">${data.remaining ? data.remaining.display : '—'}</div>
      <div class="note" style="margin-top:4px;margin-bottom:12px">remaining balance</div>
      <span class=${'badge ' + sc}>${data.status}</span>
      <div class="divider"></div>
      ${data.shopName ? html`<div class="kv-row"><span class="kv-key">Shop</span><span class="kv-val">${data.shopName}</span></div>` : null}
      ${data.beneficiaryId ? html`<div class="kv-row"><span class="kv-key">For</span><span class="kv-val">${data.beneficiaryId}</span></div>` : null}
      <div class="kv-row"><span class="kv-key">Funded</span><span class="kv-val">${data.funded ? data.funded.display : '—'}</span></div>
      <div class="kv-row"><span class="kv-key">Spent</span><span class="kv-val">${data.spent ? data.spent.display : '—'}</span></div>
      ${cats ? html`<div class="kv-row"><span class="kv-key">Allowed</span><span class="kv-val" style="color:var(--indigo)">${cats}</span></div>` : null}
      ${expiry ? html`<div class="kv-row"><span class="kv-key">Expires</span><span class="kv-val">${expiry}</span></div>` : null}
      ${histCount > 0 ? html`
        <div style="margin-top:12px">
          <button class="btn btn-ghost btn-sm" onClick=${function() { setOpen(function(o) { return !o; }); }} style="margin-bottom:8px">
            ${toggleLabel}
          </button>
          ${open ? html`<${PurchaseHistory} history=${data.history} />` : null}
        </div>` : null}
    </div>`;
}

// ── Corridor ──────────────────────────────────────────────────────────────────
function Corridor(props) {
  var quote = props.quote;
  var animate = props.animate;
  if (!quote) return null;
  var debitVal   = (Number(quote.debitAmount   ? quote.debitAmount.value   : 0) / 100).toFixed(2);
  var receiveVal = (Number(quote.receiveAmount  ? quote.receiveAmount.value : 0) / 100).toFixed(2);
  var debitCode   = quote.debitAmount   ? quote.debitAmount.assetCode   : '';
  var receiveCode = quote.receiveAmount ? quote.receiveAmount.assetCode : '';
  var fee = (Number(quote.debitAmount ? quote.debitAmount.value : 0) / 100 * 0.01).toFixed(2);
  var STEPS = ['discover','in-grant','in-payment','quote-grant','quote','out-grant','continue','out-payment'];
  var packets = animate ? [0,1,2,3,4].map(function(i) {
    return html`<span key=${i} class="corridor-packet" style=${'animation-delay:' + (i * 0.22) + 's'}></span>`;
  }) : null;
  return html`
    <div class="corridor">
      <div class="corridor-track"></div>
      ${packets}
      <div class="corridor-row">
        <div class="corridor-node">
          <div class="corridor-flag">SENDER</div>
          <div class="corridor-amt-out">-${debitCode} ${debitVal}</div>
          <div class="corridor-lbl">you send</div>
        </div>
        <div class="corridor-hub">
          <div class="corridor-ring">ILP</div>
          <div class="corridor-fx">fee ≈${fee}</div>
        </div>
        <div class="corridor-node">
          <div class="corridor-flag">SHOP</div>
          <div class="corridor-amt-in">+${receiveCode} ${receiveVal}</div>
          <div class="corridor-lbl">shop gets</div>
        </div>
      </div>
      <div class="steps">
        ${STEPS.map(function(s, i) {
          var cls = (animate || i < 6) ? 'step-pill done' : 'step-pill';
          return html`<span key=${i} class=${cls}>${i + 1} ${s}</span>`;
        })}
      </div>
    </div>`;
}

// ════════════════════════════════════════════════════════════════════
// SEND SCREEN
// ════════════════════════════════════════════════════════════════════
var CATS = ['groceries', 'medicine', 'school', 'fuel'];

function blankPayment() {
  return {
    id: Date.now() + Math.random(),
    shopName: '', shopWallet: '', amount: '', currency: 'ZAR',
    cats: { groceries: true, medicine: false, school: false, fuel: false }
  };
}

function SendScreen(props) {
  var account = props.account;
  var _p = useState([blankPayment()]); var payments = _p[0]; var setPayments = _p[1];
  var _b = useState('');  var beneficiaryId = _b[0]; var setBenId = _b[1];
  var _r = useState(null); var results = _r[0]; var setResults = _r[1];
  var _e = useState('');  var err = _e[0]; var setErr = _e[1];
  var _busy = useState(false); var busy = _busy[0]; var setBusy = _busy[1];
  var _f = useState(false); var funded = _f[0]; var setFunded = _f[1];

  useEffect(function() {
    var q = new URLSearchParams(location.search);
    var fs = q.get('funded');
    if (fs) {
      var saved = JSON.parse(localStorage.getItem('lastRemitResults') || 'null');
      if (saved) { setResults(saved); setFunded(true); }
      history.replaceState({}, '', '/');
    }
  }, []);

  function updatePayment(id, key, val) {
    setPayments(function(ps) {
      return ps.map(function(p) { return p.id === id ? Object.assign({}, p, { [key]: val }) : p; });
    });
  }
  function toggleCat(id, cat) {
    setPayments(function(ps) {
      return ps.map(function(p) {
        if (p.id !== id) return p;
        var newCats = Object.assign({}, p.cats, { [cat]: !p.cats[cat] });
        return Object.assign({}, p, { cats: newCats });
      });
    });
  }
  function addRow() { setPayments(function(ps) { return ps.concat([blankPayment()]); }); }
  function removeRow(id) { setPayments(function(ps) { return ps.filter(function(p) { return p.id !== id; }); }); }

  function doSend() {
    setErr(''); setBusy(true);
    for (var i = 0; i < payments.length; i++) {
      if (!payments[i].shopWallet || !payments[i].amount) {
        setErr('Each payment needs a shop wallet and amount.');
        setBusy(false); return;
      }
    }
    var body = {
      senderWallet: account.walletAddress,
      beneficiaryId: beneficiaryId || undefined,
      payments: payments.map(function(p) {
        return {
          shopWallet: p.shopWallet,
          shopName: p.shopName || undefined,
          amount: p.amount,
          currency: p.currency,
          allowedCategories: CATS.filter(function(c) { return p.cats[c]; })
        };
      })
    };
    sApi('/api/remittances', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Idempotency-Key': crypto.randomUUID() },
      body: JSON.stringify(body)
    }).then(function(resp) {
      setBusy(false);
      if (!resp.ok) { setErr(resp.body.error || 'Could not create remittance.'); return; }
      localStorage.setItem('lastRemitResults', JSON.stringify(resp.body.results));
      setResults(resp.body.results);
      if (resp.body.redirectUrl) location.href = resp.body.redirectUrl;
    }).catch(function(e) { setBusy(false); setErr(e.message); });
  }

  function reset() { setResults(null); setFunded(false); setPayments([blankPayment()]); setBenId(''); setErr(''); }

  // ── Funded success ──
  if (results && funded) {
    return html`
      <div class="page">
        <div class="card" style="text-align:center;padding:28px 20px">
          <div style="font-size:48px;margin-bottom:12px">🎉</div>
          <div class="card-title">Payments sent!</div>
          <p class="card-sub">Share each reference number with your loved one to use at the shop.</p>
        </div>
        ${results.map(function(r, i) {
          return html`
            <div key=${i} class="card">
              <div style="font:600 12px/1 var(--body);color:var(--text3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">${r.shopName || r.shopWallet}</div>
              <div class="ref-number">${r.reference}</div>
              <div style="display:flex;gap:8px;margin-top:12px">
                <${CopyBtn} text=${r.reference} />
              </div>
              <${Corridor} quote=${r.quote} animate=${true} />
            </div>`;
        })}
        <div style="padding:0 16px 24px">
          <button class="btn btn-ghost" onClick=${reset}>Send another</button>
        </div>
      </div>`;
  }

  // ── Awaiting consent ──
  if (results && !funded) {
    return html`
      <div class="page">
        <div class="card" style="text-align:center;padding:28px 20px">
          <div style="font-size:40px;margin-bottom:12px">🔐</div>
          <div class="card-title">Approve the payment</div>
          <p class="card-sub">You'll be taken to your Interledger wallet to approve the debit.</p>
        </div>
        ${results.map(function(r, i) { return html`<${Corridor} key=${i} quote=${r.quote} animate=${false} />`; })}
        <div style="padding:0 16px 24px">
          <button class="btn btn-green" onClick=${function() { location.href = results[0].redirectUrl; }}>Approve & Pay →</button>
          <button class="btn btn-ghost" onClick=${reset} style="margin-top:10px">Cancel</button>
        </div>
      </div>`;
  }

  // ── Build form ──
  return html`
    <div class="page">
      <div class="card">
        <div class="card-title">Send money home</div>
        <p class="card-sub">Funds go directly to a shop's wallet — locked to only what you choose.</p>
        <div class="field">
          <label>Your wallet address</label>
          <input value=${account.walletAddress} disabled style="opacity:.6" />
        </div>
        <div class="field">
          <label>For (name — optional)</label>
          <input value=${beneficiaryId} placeholder="e.g. Sipho, Maria" onInput=${function(e) { setBenId(e.target.value); }} />
        </div>
      </div>

      ${payments.map(function(p, idx) {
        return html`
          <div key=${p.id} class="card" style="position:relative">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
              <div style="font:700 14px/1 var(--display);color:var(--text)">Shop ${idx + 1}</div>
              ${payments.length > 1
                ? html`<button class="btn-danger" onClick=${function() { removeRow(p.id); }}>✕ Remove</button>`
                : null}
            </div>
            <div class="field">
              <label>Shop name (optional)</label>
              <input value=${p.shopName} placeholder="e.g. Shoprite, ABC School"
                onInput=${function(e) { updatePayment(p.id, 'shopName', e.target.value); }} />
            </div>
            <div class="field">
              <label>Shop wallet address</label>
              <input value=${p.shopWallet} placeholder="https://wallet.interledger-test.dev/shopname"
                onInput=${function(e) { updatePayment(p.id, 'shopWallet', e.target.value); }} />
            </div>
            <div class="row-2">
              <div class="field" style="margin:0">
                <label>Amount</label>
                <input type="number" min="0.01" step="0.01" value=${p.amount} placeholder="0.00"
                  onInput=${function(e) { updatePayment(p.id, 'amount', e.target.value); }} />
              </div>
              <div class="field" style="margin:0">
                <label>Currency</label>
                <select value=${p.currency} onChange=${function(e) { updatePayment(p.id, 'currency', e.target.value); }}>
                  <option value="ZAR">ZAR</option>
                  <option value="USD">USD</option>
                  <option value="GBP">GBP</option>
                  <option value="EUR">EUR</option>
                  <option value="KES">KES</option>
                </select>
              </div>
            </div>
            <div class="section-label" style="margin-top:14px">What can be bought</div>
            <div class="chips">
              ${CATS.map(function(c) {
                var cls = p.cats[c] ? 'chip on' : 'chip';
                return html`<span key=${c} class=${cls} onClick=${function() { toggleCat(p.id, c); }}>${c}</span>`;
              })}
            </div>
          </div>`;
      })}

      <div style="padding:0 16px 24px">
        <button class="btn btn-ghost" onClick=${addRow} style="margin-bottom:12px">+ Add another shop</button>
        ${err ? html`<div class="err-msg" style="margin-bottom:12px">${err}</div>` : null}
        <button class="btn btn-primary" disabled=${busy} onClick=${doSend}>
          ${busy ? '⏳ Getting quote…' : '💸 Get quote & send'}
        </button>
      </div>
    </div>`;
}

// ════════════════════════════════════════════════════════════════════
// TRACK SCREEN
// ════════════════════════════════════════════════════════════════════
function TrackScreen(props) {
  var _tab = useState('mine'); var tab = _tab[0]; var setTab = _tab[1];
  var _rems = useState([]); var remittances = _rems[0]; var setRemittances = _rems[1];
  var _load = useState(false); var loading = _load[0]; var setLoading = _load[1];
  var _ref = useState(''); var ref = _ref[0]; var setRef = _ref[1];
  var _rd = useState(null); var refData = _rd[0]; var setRefData = _rd[1];
  var _err = useState(''); var err = _err[0]; var setErr = _err[1];

  useEffect(function() {
    if (tab === 'mine') {
      setLoading(true); setErr('');
      sApi('/api/remittances').then(function(resp) {
        setLoading(false);
        if (resp.ok) setRemittances(resp.body);
        else setErr(resp.body.error || 'Could not load.');
      });
    }
  }, [tab]);

  function doLookup() {
    var r = ref.trim().toUpperCase();
    if (!r) return;
    setErr(''); setRefData(null);
    apiCall('/api/references/' + encodeURIComponent(r)).then(function(resp) {
      if (resp.ok) setRefData(resp.body);
      else setErr(resp.body.error || 'Reference not found.');
    });
  }

  function switchToMine() { setTab('mine'); setRefData(null); setErr(''); }
  function switchToLookup() { setTab('lookup'); setErr(''); }

  return html`
    <div class="page">
      <div style="display:flex;gap:8px;margin-bottom:16px">
        <button class=${tab === 'mine' ? 'btn btn-sm btn-primary' : 'btn btn-sm btn-ghost'} style="flex:1" onClick=${switchToMine}>My payments</button>
        <button class=${tab === 'lookup' ? 'btn btn-sm btn-primary' : 'btn btn-sm btn-ghost'} style="flex:1" onClick=${switchToLookup}>Look up ref</button>
      </div>

      ${err ? html`<div class="err-msg">${err}</div>` : null}

      ${tab === 'mine' ? html`
        <div>
          ${loading
            ? html`<div class="empty"><div class="empty-icon">⏳</div>Loading…</div>`
            : remittances.length === 0
              ? html`<div class="empty"><div class="empty-icon">💸</div>No payments yet. Use Send to get started.</div>`
              : remittances.map(function(r, i) { return html`<${RefCard} key=${i} data=${r} />`; })}
        </div>` : null}

      ${tab === 'lookup' ? html`
        <div>
          <div class="card">
            <div class="card-title">Check a reference</div>
            <p class="card-sub">Enter any reference number to see balance and purchase history.</p>
            <div class="lookup-row">
              <div class="field" style="margin:0">
                <label>Reference number</label>
                <input value=${ref} placeholder="e.g. GROC-AB3K9"
                  onInput=${function(e) { setRef(e.target.value.toUpperCase()); }}
                  onKeyDown=${function(e) { if (e.key === 'Enter') doLookup(); }} />
              </div>
              <button class="btn btn-primary btn-sm" style="flex-shrink:0;width:auto" onClick=${doLookup}>Search</button>
            </div>
          </div>
          ${refData ? html`<${RefCard} data=${refData} />` : null}
        </div>` : null}
    </div>`;
}

// ════════════════════════════════════════════════════════════════════
// STORE TILL
// ════════════════════════════════════════════════════════════════════
function StoreTill(props) {
  var store = props.store;
  var _ref = useState(''); var ref = _ref[0]; var setRef = _ref[1];
  var _data = useState(null); var data = _data[0]; var setData = _data[1];
  var _err = useState(''); var err = _err[0]; var setErr = _err[1];
  var _amt = useState(''); var amount = _amt[0]; var setAmt = _amt[1];
  var _cat = useState('groceries'); var category = _cat[0]; var setCat = _cat[1];
  var _flash = useState(''); var flash = _flash[0]; var setFlash = _flash[1];
  var _busy = useState(false); var busy = _busy[0]; var setBusy = _busy[1];

  function doLookup() {
    var r = ref.trim().toUpperCase();
    if (!r) return;
    setErr(''); setFlash(''); setData(null);
    apiCall('/api/references/' + encodeURIComponent(r)).then(function(resp) {
      if (!resp.ok) { setErr(resp.body.error || 'Reference not found.'); return; }
      if (resp.body.shopWallet && resp.body.shopWallet !== store.walletAddress) {
        setErr('This reference is not assigned to your store.'); return;
      }
      setData(resp.body);
      var cats = resp.body.allowedCategories;
      if (cats && cats.length > 0) setCat(cats[0]);
    });
  }

  function doCharge() {
    setErr(''); setFlash(''); setBusy(true);
    tApi('/api/purchases', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Idempotency-Key': crypto.randomUUID() },
      body: JSON.stringify({ reference: data.reference, amount: amount, category: category })
    }).then(function(resp) {
      setBusy(false);
      if (!resp.ok) { setErr(resp.body.reason || resp.body.error || 'Charge declined.'); return; }
      setFlash('✅ Charged ' + resp.body.spent + '. Remaining: ' + resp.body.remaining + '.');
      setAmt('');
      return apiCall('/api/references/' + encodeURIComponent(data.reference)).then(function(r2) {
        if (r2.ok) setData(r2.body);
      });
    }).catch(function(e) { setBusy(false); setErr(e.message); });
  }

  var sc = data ? statusClass(data.status) : '';
  var cats = data
    ? (data.allowedCategories && data.allowedCategories.length > 0 ? data.allowedCategories : ['groceries','medicine','school','fuel','other'])
    : [];
  var canCharge = data && data.status !== 'EXHAUSTED' && data.status !== 'EXPIRED' && data.status !== 'PENDING_FUNDING';

  return html`
    <div class="page">
      <div class="shop-header">
        <h2>🏪 Store Till</h2>
        <p>Look up a customer reference to check balance and charge.</p>
        <div style="margin-top:8px;font:600 11px/1 var(--body);color:rgba(255,255,255,.7)">${store.storeName}</div>
      </div>

      <div class="card">
        <div class="lookup-row">
          <div class="field" style="margin:0">
            <label>Customer reference</label>
            <input value=${ref} placeholder="GROC-AB3K9"
              onInput=${function(e) { setRef(e.target.value.toUpperCase()); }}
              onKeyDown=${function(e) { if (e.key === 'Enter') doLookup(); }} />
          </div>
          <button class="btn btn-primary btn-sm" style="flex-shrink:0;width:auto" onClick=${doLookup}>Look up</button>
        </div>
        ${err && !data ? html`<div class="err-msg" style="margin-top:10px">${err}</div>` : null}
      </div>

      ${data ? html`
        <div>
          <div class="card">
            <div class="big-amount">${data.remaining ? data.remaining.display : '—'}</div>
            <div class="note" style="margin-top:4px;margin-bottom:10px">available to spend</div>
            <span class=${'badge ' + sc}>${data.status}</span>
            <div class="divider"></div>
            ${data.beneficiaryId ? html`<div class="kv-row"><span class="kv-key">Customer</span><span class="kv-val">${data.beneficiaryId}</span></div>` : null}
            <div class="kv-row">
              <span class="kv-key">Allowed</span>
              <span class="kv-val" style="color:var(--indigo)">${data.allowedCategories && data.allowedCategories.length > 0 ? data.allowedCategories.join(', ') : 'any'}</span>
            </div>
            <div class="kv-row"><span class="kv-key">Funded</span><span class="kv-val">${data.funded ? data.funded.display : '—'}</span></div>
            <div class="kv-row"><span class="kv-key">Spent</span><span class="kv-val">${data.spent ? data.spent.display : '—'}</span></div>
          </div>

          ${canCharge ? html`
            <div class="card">
              <div class="card-title">Charge this reference</div>
              <div class="field">
                <label>Amount</label>
                <input type="number" min="0.01" step="0.01" value=${amount} placeholder="0.00"
                  onInput=${function(e) { setAmt(e.target.value); }} />
              </div>
              <div class="field">
                <label>Category</label>
                <select value=${category} onChange=${function(e) { setCat(e.target.value); }}>
                  ${cats.map(function(c) { return html`<option key=${c} value=${c}>${c}</option>`; })}
                </select>
              </div>
              ${flash ? html`<div class="ok-msg">${flash}</div>` : null}
              ${err ? html`<div class="err-msg">${err}</div>` : null}
              <button class="btn btn-green" disabled=${!amount || busy} onClick=${doCharge} style="margin-top:4px">
                ${busy ? '⏳ Processing…' : 'Charge ' + (amount ? (data.remaining ? data.remaining.assetCode : '') + ' ' + amount : '')}
              </button>
              <p class="note">Purchases outside allowed categories are automatically declined.</p>
            </div>` : null}

          ${data.history && data.history.length > 0 ? html`
            <div class="card">
              <div class="card-title" style="margin-bottom:12px">Transaction history</div>
              <${PurchaseHistory} history=${data.history} />
            </div>` : null}
        </div>` : null}
    </div>`;
}

// ════════════════════════════════════════════════════════════════════
// STORE OVERVIEW
// ════════════════════════════════════════════════════════════════════
function StoreOverview(props) {
  var store = props.store;
  var _rems = useState([]); var remittances = _rems[0]; var setRemittances = _rems[1];
  var _load = useState(true); var loading = _load[0]; var setLoading = _load[1];
  var _err = useState(''); var err = _err[0]; var setErr = _err[1];

  useEffect(function() {
    tApi('/api/store/remittances').then(function(resp) {
      setLoading(false);
      if (resp.ok) setRemittances(resp.body);
      else setErr(resp.body.error || 'Could not load.');
    });
  }, []);

  var totalFunded = remittances.reduce(function(s, r) { return s + Number(r.funded ? r.funded.value : 0); }, 0);
  var totalSpent  = remittances.reduce(function(s, r) { return s + Number(r.spent  ? r.spent.value  : 0); }, 0);
  var code  = remittances.length > 0 && remittances[0].funded ? remittances[0].funded.assetCode  : '';
  var scale = remittances.length > 0 && remittances[0].funded ? remittances[0].funded.assetScale : 2;
  var fmt = function(v) { return (v / Math.pow(10, scale)).toFixed(2) + (code ? ' ' + code : ''); };

  return html`
    <div class="page">
      <div class="shop-header">
        <h2>📊 Overview</h2>
        <p>${store.storeName}</p>
        <div style="margin-top:6px;font:400 11px/1.4 var(--body);color:rgba(255,255,255,.55);word-break:break-all">${store.walletAddress}</div>
      </div>

      ${err ? html`<div class="err-msg">${err}</div>` : null}

      ${!loading && remittances.length > 0 ? html`
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
          <div class="card" style="margin-bottom:0;text-align:center">
            <div class="note">Total received</div>
            <div style="font:800 18px/1 var(--display);color:var(--blue);margin-top:6px">${fmt(totalFunded)}</div>
          </div>
          <div class="card" style="margin-bottom:0;text-align:center">
            <div class="note">Total spent</div>
            <div style="font:800 18px/1 var(--display);color:var(--green);margin-top:6px">${fmt(totalSpent)}</div>
          </div>
        </div>` : null}

      ${loading
        ? html`<div class="empty"><div class="empty-icon">⏳</div>Loading…</div>`
        : remittances.length === 0
          ? html`<div class="empty"><div class="empty-icon">📭</div>No remittances received yet.</div>`
          : remittances.map(function(r, i) { return html`<${RefCard} key=${i} data=${r} />`; })}
    </div>`;
}

// ════════════════════════════════════════════════════════════════════
// AUTH SCREEN
// ════════════════════════════════════════════════════════════════════
function AuthScreen() {
  var _at = useState(null); var accountType = _at[0]; var setAccountType = _at[1];
  var _m = useState('login'); var mode = _m[0]; var setMode = _m[1];
  var _f = useState({ email:'', password:'', displayName:'', walletAddress:'', storeName:'' });
  var form = _f[0]; var setForm = _f[1];
  var _err = useState(''); var err = _err[0]; var setErr = _err[1];
  var _busy = useState(false); var busy = _busy[0]; var setBusy = _busy[1];

  function setField(k, v) { setForm(function(s) { return Object.assign({}, s, { [k]: v }); }); }

  function doSubmit() {
    setErr(''); setBusy(true);
    var endpoint, payload, tokenKey;
    if (accountType === 'sender') {
      endpoint = mode === 'login' ? '/api/login' : '/api/register';
      payload = mode === 'login'
        ? { email: form.email, password: form.password }
        : { email: form.email, password: form.password, displayName: form.displayName, walletAddress: form.walletAddress };
      tokenKey = 'authToken';
    } else {
      endpoint = mode === 'login' ? '/api/store/login' : '/api/store/register';
      payload = mode === 'login'
        ? { email: form.email, password: form.password }
        : { email: form.email, password: form.password, storeName: form.storeName, walletAddress: form.walletAddress };
      tokenKey = 'storeToken';
    }
    apiCall(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).then(function(resp) {
      setBusy(false);
      if (!resp.ok) { setErr(resp.body.error || 'Authentication failed.'); return; }
      localStorage.setItem(tokenKey, resp.body.token);
      localStorage.setItem('accountType', accountType);
      window.location.reload();
    }).catch(function(e) { setBusy(false); setErr(e.message); });
  }

  // Step 1 — pick account type
  if (!accountType) {
    return html`
      <div class="auth-page">
        <div class="auth-logo">
          <div class="mark">R</div>
          <h1>RemitSafe</h1>
          <p>Restricted remittance on Interledger</p>
        </div>
        <div style="width:100%;max-width:400px;display:flex;flex-direction:column;gap:14px">
          <button class="type-card" onClick=${function() { setAccountType('sender'); }}>
            <div class="type-icon">👤</div>
            <div>
              <div class="type-title">I'm a Sender</div>
              <div class="type-desc">Parent or worker abroad sending money home</div>
            </div>
            <div class="type-arrow">›</div>
          </button>
          <button class="type-card" onClick=${function() { setAccountType('store'); }}>
            <div class="type-icon">🏪</div>
            <div>
              <div class="type-title">I'm a Store / Institution</div>
              <div class="type-desc">Shop or school receiving restricted payments</div>
            </div>
            <div class="type-arrow">›</div>
          </button>
        </div>
      </div>`;
  }

  // Step 2 — login / register form
  var isSender = accountType === 'sender';
  var walletPlaceholder = isSender
    ? 'https://wallet.interledger-test.dev/yourname'
    : 'https://wallet.interledger-test.dev/storename';

  return html`
    <div class="auth-page">
      <div class="auth-logo">
        <div class="mark">${isSender ? '👤' : '🏪'}</div>
        <h1>${isSender ? 'Sender' : 'Store'} Account</h1>
        <p>${mode === 'login' ? 'Sign in to continue' : 'Create your account'}</p>
      </div>
      <div class="auth-card">
        <div style="display:flex;gap:8px;margin-bottom:20px">
          <button class=${mode === 'login' ? 'btn btn-sm btn-primary' : 'btn btn-sm btn-ghost'} style="flex:1"
            onClick=${function() { setMode('login'); setErr(''); }}>Sign in</button>
          <button class=${mode === 'register' ? 'btn btn-sm btn-primary' : 'btn btn-sm btn-ghost'} style="flex:1"
            onClick=${function() { setMode('register'); setErr(''); }}>Register</button>
        </div>

        ${err ? html`<div class="err-msg">${err}</div>` : null}

        <div class="field">
          <label>Email address</label>
          <input type="email" placeholder="you@example.com" value=${form.email}
            onInput=${function(e) { setField('email', e.target.value); }} />
        </div>

        ${mode === 'register' && isSender ? html`
          <div class="field">
            <label>Your name</label>
            <input placeholder="Your full name" value=${form.displayName}
              onInput=${function(e) { setField('displayName', e.target.value); }} />
          </div>` : null}

        ${mode === 'register' && !isSender ? html`
          <div class="field">
            <label>Store / institution name</label>
            <input placeholder="e.g. Shoprite Nairobi, ABC School" value=${form.storeName}
              onInput=${function(e) { setField('storeName', e.target.value); }} />
          </div>` : null}

        ${mode === 'register' ? html`
          <div class="field">
            <label>Interledger wallet address</label>
            <input placeholder=${walletPlaceholder} value=${form.walletAddress}
              onInput=${function(e) { setField('walletAddress', e.target.value); }} />
          </div>` : null}

        <div class="field">
          <label>Password</label>
          <input type="password" placeholder="••••••••" value=${form.password}
            onInput=${function(e) { setField('password', e.target.value); }} />
        </div>

        <button class="btn btn-primary" disabled=${busy || !form.email || !form.password} onClick=${doSubmit}>
          ${busy ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'}
        </button>

        <div style="text-align:center;margin-top:16px">
          <button style="background:none;border:none;color:var(--text3);font-size:13px;cursor:pointer"
            onClick=${function() { setAccountType(null); setErr(''); }}>
            ← Back
          </button>
        </div>
      </div>
    </div>`;
}

// ════════════════════════════════════════════════════════════════════
// ROOT APP
// ════════════════════════════════════════════════════════════════════
function App() {
  var _s = useState({ loading: true, account: null, store: null, accountType: null });
  var state = _s[0]; var setState = _s[1];
  var _tab = useState('main'); var tab = _tab[0]; var setTab = _tab[1];
  var _mock = useState(true); var mock = _mock[0]; var setMock = _mock[1];

  useEffect(function() {
    apiCall('/api/health').then(function(r) { if (r.ok) setMock(r.body.mock); });
    var type = localStorage.getItem('accountType');
    if (type === 'sender') {
      sApi('/api/me').then(function(resp) {
        if (resp.ok) setState({ loading: false, account: resp.body, store: null, accountType: 'sender' });
        else {
          localStorage.removeItem('authToken');
          localStorage.removeItem('accountType');
          setState({ loading: false, account: null, store: null, accountType: null });
        }
      });
    } else if (type === 'store') {
      tApi('/api/store/me').then(function(resp) {
        if (resp.ok) setState({ loading: false, account: null, store: resp.body, accountType: 'store' });
        else {
          localStorage.removeItem('storeToken');
          localStorage.removeItem('accountType');
          setState({ loading: false, account: null, store: null, accountType: null });
        }
      });
    } else {
      setState({ loading: false, account: null, store: null, accountType: null });
    }
  }, []);

  function signOut() {
    localStorage.removeItem('authToken');
    localStorage.removeItem('storeToken');
    localStorage.removeItem('accountType');
    localStorage.removeItem('lastRemitResults');
    window.location.reload();
  }

  if (state.loading) {
    return html`<div class="loading-page"><div class="spinner"></div></div>`;
  }

  if (!state.account && !state.store) {
    return html`<${AuthScreen} />`;
  }

  var isSender = state.accountType === 'sender';
  var name = isSender
    ? (state.account.displayName || state.account.email.split('@')[0])
    : state.store.storeName;
  var walletAddr = isSender ? state.account.walletAddress : state.store.walletAddress;
  var initial = name.charAt(0).toUpperCase();

  var senderTabs = [{ id:'main', icon:'💸', label:'Send' }, { id:'track', icon:'📋', label:'Track' }];
  var storeTabs  = [{ id:'main', icon:'🏪', label:'Till'  }, { id:'overview', icon:'📊', label:'Overview' }];
  var tabs = isSender ? senderTabs : storeTabs;

  return html`
    <div class="app-shell">
      <div class="top-header">
        <div class="header-row">
          <div class="header-brand">Remit<span>Safe</span></div>
          <div class="header-user">
            <span class="mock-badge">${mock ? 'test net' : 'live net'}</span>
            <div class="header-avatar">${initial}</div>
            <button class="logout-btn" onClick=${signOut}>Sign out</button>
          </div>
        </div>
        <div class="balance-card">
          <div class="balance-label">Welcome, ${name} ${isSender ? '👋' : '🏪'}</div>
          <div class="balance-amount">${isSender ? 'Send & Track' : 'Store Dashboard'}</div>
          <div class="balance-sub" style="word-break:break-all;font-size:11px;opacity:.7">${walletAddr}</div>
        </div>
      </div>

      ${isSender && tab === 'main'      ? html`<${SendScreen}    account=${state.account} />` : null}
      ${isSender && tab === 'track'     ? html`<${TrackScreen}   account=${state.account} />` : null}
      ${!isSender && tab === 'main'     ? html`<${StoreTill}     store=${state.store} />`    : null}
      ${!isSender && tab === 'overview' ? html`<${StoreOverview} store=${state.store} />`    : null}

      <nav class="tab-nav">
        ${tabs.map(function(t) {
          return html`
            <button key=${t.id} class=${tab === t.id ? 'tab-btn active' : 'tab-btn'} onClick=${function() { setTab(t.id); }}>
              <span class="tab-icon">${t.icon}</span>${t.label}
            </button>`;
        })}
      </nav>
    </div>`;
}

ReactDOM.createRoot(document.getElementById('root')).render(html`<${App} />`);
