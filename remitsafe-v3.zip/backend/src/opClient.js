// opClient.js — returns either a real authenticated Open Payments client or a
// mock client with the SAME method surface, so flow.js never branches on mode.
//
// Real mode needs (in .env):
//   OP_CLIENT_WALLET_URL  the wallet address THIS app identifies itself by
//   OP_KEY_ID             the key id registered on that wallet
//   OP_PRIVATE_KEY_PATH   path to the Ed25519 private key (PEM)
//
// Mock mode (MOCK_MODE=true) needs none of the above and never touches the network.
import fs from 'node:fs';
import crypto from 'node:crypto';
import {
  createAuthenticatedClient,
  isPendingGrant,
  isFinalizedGrant,
} from '@interledger/open-payments';

export { isPendingGrant, isFinalizedGrant };

const MOCK = String(process.env.MOCK_MODE).toLowerCase() === 'true';

// ---------------------------------------------------------------------------
// Real client
// ---------------------------------------------------------------------------
async function realClient() {
  return createAuthenticatedClient({
    walletAddressUrl: process.env.OP_CLIENT_WALLET_URL,
    keyId: process.env.OP_KEY_ID,
    privateKey: fs.readFileSync(process.env.OP_PRIVATE_KEY_PATH),
    // useHttp: true, // uncomment ONLY for a local http Rafiki dev stack
  });
}

// ---------------------------------------------------------------------------
// Mock client — deterministic, offline, mirrors the real surface used by flow.js
// ---------------------------------------------------------------------------
const id = (p) => `${p}_${crypto.randomBytes(6).toString('hex')}`;

function mockWallet(url) {
  const base = url.replace(/\/$/, '');
  return {
    id: base,
    authServer: `${base.replace(/\/[^/]+$/, '')}/auth`,
    resourceServer: base.replace(/\/[^/]+$/, ''),
    assetCode: url.includes('shop') || url.includes('shilling') ? 'KES' : 'ZAR',
    assetScale: 2,
    publicName: base.split('/').pop(),
  };
}

function mockClient(baseUrl) {
  const store = new Map();
  return {
    walletAddress: {
      async get({ url }) {
        return mockWallet(url);
      },
    },
    grant: {
      async request(_postArgs, args) {
        const wantsInteract = !!args.interact;
        if (wantsInteract) {
          const continueToken = id('continue');
          const grantId = id('grant');
          return {
            interact: {
              redirect: `${baseUrl}/mock-consent?grant=${grantId}`,
              finish: id('finish'),
            },
            continue: {
              uri: `${baseUrl}/mock/continue/${grantId}`,
              access_token: { value: continueToken },
              wait: 0,
            },
          };
        }
        // Non-interactive grant -> finalized immediately.
        return { access_token: { value: id('token'), manage: id('manage') }, continue: {} };
      },
      async continue(_postArgs, _args) {
        return { access_token: { value: id('token'), manage: id('manage') } };
      },
    },
    incomingPayment: {
      async create({ url: _url }, body) {
        const ip = {
          id: `${body.walletAddress}/incoming-payments/${crypto.randomUUID()}`,
          walletAddress: body.walletAddress,
          incomingAmount: body.incomingAmount,
          receivedAmount: { value: '0', assetCode: body.incomingAmount.assetCode, assetScale: body.incomingAmount.assetScale },
          metadata: body.metadata || {},
          completed: false,
          expiresAt: body.expiresAt,
          createdAt: new Date().toISOString(),
          methods: [{ type: 'ilp', ilpAddress: `g.mock.${crypto.randomBytes(3).toString('hex')}`, sharedSecret: crypto.randomBytes(32).toString('base64') }],
        };
        store.set(ip.id, ip);
        return ip;
      },
    },
    quote: {
      async create({ url: _url }, body) {
        // Mock a small FX spread + sender fee to make the "ILP magic" visible.
        const recv = BigInt(store.get(body.receiver)?.incomingAmount?.value || '0');
        const fee = recv / 100n;           // 1% network/sender fee
        const fx = 700n;                   // ZAR->KES style scaled rate (illustrative)
        const debit = (recv * fx) / 1000n + fee;
        return {
          id: `${body.walletAddress}/quotes/${crypto.randomUUID()}`,
          walletAddress: body.walletAddress,
          receiver: body.receiver,
          receiveAmount: store.get(body.receiver)?.incomingAmount || { value: recv.toString(), assetCode: 'KES', assetScale: 2 },
          debitAmount: { value: debit.toString(), assetCode: 'ZAR', assetScale: 2 },
          method: 'ilp',
          createdAt: new Date().toISOString(),
        };
      },
    },
    outgoingPayment: {
      async create({ url: _url }, body) {
        return {
          id: `${body.walletAddress}/outgoing-payments/${crypto.randomUUID()}`,
          walletAddress: body.walletAddress,
          quoteId: body.quoteId,
          metadata: body.metadata || {},
          sentAmount: { value: '0', assetCode: 'ZAR', assetScale: 2 },
          failed: false,
          createdAt: new Date().toISOString(),
        };
      },
    },
    _store: store,
  };
}

let _client;
export async function getClient(baseUrl) {
  if (_client) return _client;
  _client = MOCK ? mockClient(baseUrl) : await realClient();
  return _client;
}

export const isMock = MOCK;
