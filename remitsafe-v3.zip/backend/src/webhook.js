// webhook.js — Rafiki posts events here. We confirm settlement from webhooks,
// never by polling. Events are deduped by id so a re-delivery is harmless.
//
// Relevant Rafiki events:
//   incoming_payment.completed   -> funds fully landed at the shop
//   incoming_payment.created     -> (informational)
//   outgoing_payment.completed   -> sender's debit finished
//   outgoing_payment.failed      -> sender's debit failed
import db from './db.js';
import { confirmFunding } from './flow.js';

export function handleWebhook(event) {
  // event shape (Rafiki): { id, type, data: { id, receivedAmount, ... } }
  const eventId = event.id || `${event.type}:${event?.data?.id}`;

  // Idempotency: ignore events we've already processed.
  const seen = db.get(`SELECT id FROM webhook_events WHERE event_id=?`, [eventId]);
  if (seen) return { duplicate: true };

  db.run(
    `INSERT INTO webhook_events (event_id, event_type, resource_id, payload, processed)
     VALUES (?,?,?,?,0)`,
    [eventId, event.type, event?.data?.id || null, JSON.stringify(event)],
  );

  let result = { handled: false };

  switch (event.type) {
    case 'incoming_payment.completed':
    case 'incoming_payment.expired': {
      const received = event?.data?.receivedAmount?.value || '0';
      const rp = confirmFunding(event.data.id, received);
      result = { handled: true, fundedReference: rp?.reference_number || null };
      break;
    }
    case 'outgoing_payment.completed':
    case 'outgoing_payment.failed':
      // Sender-side settlement signal — logged for the audit trail/UI.
      result = { handled: true, note: event.type };
      break;
    default:
      result = { handled: false, note: `Ignored event ${event.type}` };
  }

  db.run(`UPDATE webhook_events SET processed=1 WHERE event_id=?`, [eventId]);
  return result;
}
