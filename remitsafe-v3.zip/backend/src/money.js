// money.js — all amounts in Open Payments are STRINGS of minor units.
// JSON has no BigInt, so we keep strings on the wire and use BigInt for math.
// e.g. "50.00" ZAR at scale 2  <->  "5000" minor units.

/** Human decimal string -> minor-unit string. toMinor("50.00", 2) === "5000" */
export function toMinor(decimalStr, assetScale) {
  const neg = String(decimalStr).trim().startsWith('-');
  const clean = String(decimalStr).replace(/[^0-9.]/g, '');
  const [whole = '0', frac = ''] = clean.split('.');
  const fracPadded = (frac + '0'.repeat(assetScale)).slice(0, assetScale);
  const minor = BigInt(whole) * 10n ** BigInt(assetScale) + BigInt(fracPadded || '0');
  return (neg ? -minor : minor).toString();
}

/** Minor-unit string -> human decimal string. toDecimal("5000", 2) === "50.00" */
export function toDecimal(minorStr, assetScale) {
  const minor = BigInt(minorStr);
  const sign = minor < 0n ? '-' : '';
  const abs = (minor < 0n ? -minor : minor).toString().padStart(assetScale + 1, '0');
  const whole = abs.slice(0, abs.length - assetScale) || '0';
  const frac = assetScale ? '.' + abs.slice(abs.length - assetScale) : '';
  return `${sign}${whole}${frac}`;
}

/** Build an Open Payments amount object from a human decimal string. */
export function amount(decimalStr, assetCode, assetScale) {
  return { value: toMinor(decimalStr, assetScale), assetCode, assetScale };
}

// BigInt string arithmetic helpers (inputs/outputs are strings).
export const add = (a, b) => (BigInt(a) + BigInt(b)).toString();
export const sub = (a, b) => (BigInt(a) - BigInt(b)).toString();
export const gte = (a, b) => BigInt(a) >= BigInt(b);
export const gt  = (a, b) => BigInt(a) > BigInt(b);
export const lte = (a, b) => BigInt(a) <= BigInt(b);
export const isZero = (a) => BigInt(a) === 0n;
export const remaining = (received, spent) => sub(received, spent);
