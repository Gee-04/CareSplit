// flow.js — the canonical 8-step Open Payments "happy path", plus the shop-side
// redemption logic. Each step is labelled to match the hackathon flow exactly.
//
// IMPORTANT (strategic point): Open Payments `metadata` is DESCRIPTIVE — the ILP
// network does not enforce "groceries only". Enforcement lives HERE, in the proxy
// backend: we check category + remaining balance before allowing a redemption.
// That enforcement IS the product.
import crypto from 'node:crypto';
import db from './db.js';
import { getClient, isPendingGrant, isMock } from './opClient.js';
import { amount, toMinor, add, sub, gte, isZero } from './money.js';
import { generateReference } from './reference.js';

const BASE_URL = () => process.env.BASE_URL || 'http://localhost:4000';

// ---------------------------------------------------------------------------
// Steps 1–6: stand up a restricted remittance and return a consent redirect.
// ---------------------------------------------------------------------------
export async function createRestrictedRemittance({
  senderWallet, shopWallet, beneficiaryId,
  allowedCategories, amountDecimal, expiryDays = 30,
  accountId = null, shopAccountId = null, shopName = null,
}) {
  const client = await getClient(BASE_URL());

  // STEP 1 — Discovery: resolve both wallet addresses (public GET, no auth).
  const sender = await client.walletAddress.get({ url: senderWallet });
  const shop = await client.walletAddress.get({ url: shopWallet });

  // STEP 2 — Incoming payment grant from the SHOP's (receiver's) auth server.
  const incomingGrant = await client.grant.request(
    { url: shop.authServer },
    { access_token: { access: [{ type: 'incoming-payment', actions: ['create', 'read', 'list'] }] } },
  );

  // STEP 3 — Create the incoming payment WITH restriction metadata. <<< deliverable
  const expiresAt = new Date(Date.now() + expiryDays * 864e5).toISOString();
  const reference = generateReference(allowedCategories);
  const incomingPayment = await client.incomingPayment.create(
    { url: shop.resourceServer, accessToken: incomingGrant.access_token.value },
    {
      walletAddress: shop.id,
      incomingAmount: amount(amountDecimal, shop.assetCode, shop.assetScale),
      expiresAt,
      metadata: {
        type: 'restricted-remittance',
        reference,                       // human-readable code the beneficiary quotes
        beneficiaryId,                   // who may redeem
        allowedCategories,               // e.g. ["groceries"]
        senderWallet,
        note: `Restricted to: ${allowedCategories.join(', ')}`,
      },
    },
  );

  // STEP 4 — Quote grant from the SENDER's auth server (non-interactive).
  const quoteGrant = await client.grant.request(
    { url: sender.authServer },
    { access_token: { access: [{ type: 'quote', actions: ['create', 'read'] }] } },
  );

  // STEP 5 — Create the quote: locks FX + fees between sender and receiver.
  const quote = await client.quote.create(
    { url: sender.resourceServer, accessToken: quoteGrant.access_token.value },
    { walletAddress: sender.id, receiver: incomingPayment.id, method: 'ilp' },
  );

  // STEP 6 — Outgoing payment grant: INTERACTIVE (user consent via redirect). <<< deliverable
  const nonce = crypto.randomBytes(16).toString('hex');
  const sessionToken = crypto.randomBytes(16).toString('hex');
  const outgoingGrant = await client.grant.request(
    { url: sender.authServer },
    {
      access_token: {
        access: [{
          type: 'outgoing-payment',
          actions: ['create', 'read'],
          identifier: sender.id,
          limits: {
            debitAmount: quote.debitAmount,     // cap = exactly this quote
            receiveAmount: quote.receiveAmount,
          },
        }],
      },
      interact: {
        start: ['redirect'],
        finish: {
          method: 'redirect',
          uri: `${BASE_URL()}/api/callback?session=${sessionToken}`,
          nonce,
        },
      },
    },
  );

  if (!isPendingGrant(outgoingGrant)) {
    throw new Error('Expected an interactive (pending) grant for the outgoing payment.');
  }

  // Persist the restricted payment (source of truth for the balance).
  const rp = db.run(
    `INSERT INTO restricted_payments
       (reference_number, incoming_payment_id, account_id, shop_account_id, shop_name,
        sender_wallet, shop_wallet, beneficiary_id,
        allowed_categories, asset_code, asset_scale, incoming_amount_value, status, expires_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [reference, incomingPayment.id, accountId, shopAccountId, shopName,
     senderWallet, shopWallet, beneficiaryId,
     JSON.stringify(allowedCategories), shop.assetCode, shop.assetScale,
     incomingPayment.incomingAmount.value, 'PENDING_FUNDING', expiresAt],
  );

  // Persist the grant session — bridges the consent redirect (step 6 -> 7 -> 8).
  // continue_token is a server-only secret; it never goes to the browser.
  db.run(
    `INSERT INTO grant_sessions
       (session_token, restricted_payment_id, quote_id, sender_wallet,
        continue_uri, continue_token, nonce, status)
     VALUES (?,?,?,?,?,?,?,?)`,
    [sessionToken, rp.lastInsertRowid, quote.id, senderWallet,
     outgoingGrant.continue.uri, outgoingGrant.continue.access_token.value,
     nonce, 'AWAITING_CONSENT'],
  );

  return {
    reference,
    sessionToken,
    redirectUrl: outgoingGrant.interact.redirect, // send the user here to approve
    incomingPaymentId: incomingPayment.id,
    quote: { id: quote.id, debitAmount: quote.debitAmount, receiveAmount: quote.receiveAmount },
    ilp: incomingPayment.methods?.[0] || null,     // ILP address + shared secret (the "magic")
  };
}

// ---------------------------------------------------------------------------
// Steps 7–8: after the user approves, the auth server redirects back with an
// interact_ref. Exchange it for a token and create the outgoing payment.
// ---------------------------------------------------------------------------
export async function finalizeRemittance({ sessionToken, interactRef }) {
  const session = db.get(`SELECT * FROM grant_sessions WHERE session_token = ?`, [sessionToken]);
  if (!session) throw new Error('Unknown grant session.');
  if (session.status === 'FINALIZED') {
    return { alreadyFinalized: true };
  }

  const client = await getClient(BASE_URL());

  // STEP 7 — Continuation: exchange interact_ref for the final access token.
  const finalized = await client.grant.continue(
    { url: session.continue_uri, accessToken: session.continue_token },
    { interact_ref: interactRef },
  );

  const sender = await client.walletAddress.get({ url: session.sender_wallet });

  // STEP 8 — Create the outgoing payment. Settlement happens out-of-band; we
  // learn it succeeded from the webhook, not by polling.
  const outgoing = await client.outgoingPayment.create(
    { url: sender.resourceServer, accessToken: finalized.access_token.value },
    {
      walletAddress: sender.id,
      quoteId: session.quote_id,
      metadata: { type: 'restricted-remittance-funding', sessionToken },
    },
  );

  db.run(`UPDATE grant_sessions SET status='FINALIZED', interact_ref=? WHERE id=?`,
    [interactRef, session.id]);

  // In MOCK_MODE there is no Rafiki to emit a webhook, so simulate the
  // incoming_payment.completed settlement confirmation immediately.
  if (isMock) {
    const rp = db.get(`SELECT * FROM restricted_payments WHERE id=?`, [session.restricted_payment_id]);
    confirmFunding(rp.incoming_payment_id, rp.incoming_amount_value);
  }

  return { outgoingPaymentId: outgoing.id };
}

// ---------------------------------------------------------------------------
// Called by the webhook (or the mock) when funds actually land at the shop.
// ---------------------------------------------------------------------------
export function confirmFunding(incomingPaymentId, receivedValue) {
  const rp = db.get(`SELECT * FROM restricted_payments WHERE incoming_payment_id=?`, [incomingPaymentId]);
  if (!rp) return null;
  db.run(
    `UPDATE restricted_payments SET received_amount_value=?, status='FUNDED' WHERE id=?`,
    [receivedValue, rp.id],
  );
  return db.get(`SELECT * FROM restricted_payments WHERE id=?`, [rp.id]);
}

// ---------------------------------------------------------------------------
// Shop side: look up a reference, check the spendable balance.
// ---------------------------------------------------------------------------
export function getByReference(reference) {
  const rp = db.get(`SELECT * FROM restricted_payments WHERE reference_number=?`, [reference]);
  if (!rp) return null;
  const remaining = sub(rp.received_amount_value, rp.spent_amount_value);
  return {
    ...rp,
    allowed_categories: JSON.parse(rp.allowed_categories),
    remaining_value: remaining,
  };
}

// ---------------------------------------------------------------------------
// Shop side: redeem against a reference. Enforces category + balance HERE.
// ---------------------------------------------------------------------------
export async function shopPurchase({ reference, amountDecimal, category }) {
  const rp = db.get(`SELECT * FROM restricted_payments WHERE reference_number=?`, [reference]);
  if (!rp) return { ok: false, reason: 'Reference not found.' };
  if (rp.status === 'PENDING_FUNDING') return { ok: false, reason: 'Not funded yet — settlement still pending.' };

  const allowed = JSON.parse(rp.allowed_categories);
  if (allowed.length && !allowed.includes(category)) {
    record(rp.id, category, '0', 'REJECTED', `Category "${category}" not allowed (${allowed.join(', ')}).`);
    return { ok: false, reason: `This voucher is restricted to: ${allowed.join(', ')}.` };
  }

  const cost = toMinor(amountDecimal, rp.asset_scale);
  const remaining = sub(rp.received_amount_value, rp.spent_amount_value);
  if (!gte(remaining, cost)) {
    record(rp.id, category, cost, 'REJECTED', 'Insufficient remaining balance.');
    return { ok: false, reason: 'Amount exceeds the remaining balance.' };
  }

  // (Real mode could create an outgoing payment shop -> till here.)
  const newSpent = add(rp.spent_amount_value, cost);
  const exhausted = isZero(sub(rp.received_amount_value, newSpent));
  db.run(
    `UPDATE restricted_payments SET spent_amount_value=?, status=? WHERE id=?`,
    [newSpent, exhausted ? 'EXHAUSTED' : 'PARTIALLY_SPENT', rp.id],
  );
  const purchaseId = record(rp.id, category, cost, 'COMPLETED', null);

  return {
    ok: true,
    purchaseId,
    spent_value: cost,
    remaining_value: sub(rp.received_amount_value, newSpent),
    asset_code: rp.asset_code,
    asset_scale: rp.asset_scale,
  };
}

function record(rpId, category, value, status, reason) {
  const r = db.run(
    `INSERT INTO purchase_history (restricted_payment_id, category, amount_value, status, rejected_reason)
     VALUES (?,?,?,?,?)`,
    [rpId, category, value, status, reason],
  );
  return r.lastInsertRowid;
}

export function purchaseHistory(reference) {
  const rp = db.get(`SELECT id FROM restricted_payments WHERE reference_number=?`, [reference]);
  if (!rp) return [];
  return db.all(`SELECT * FROM purchase_history WHERE restricted_payment_id=? ORDER BY id DESC`, [rp.id]);
}
