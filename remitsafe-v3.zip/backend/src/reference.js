// reference.js — human-readable reference numbers, e.g. GROC-7K2M9.
// The prefix hints at the allowed category so a shop clerk recognises it.
// Ambiguous characters (0/O, 1/I) are excluded so codes are easy to read aloud.
import crypto from 'node:crypto';

const ALPHABET = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'; // no 0,1,I,O
const CATEGORY_PREFIX = {
  groceries: 'GROC',
  medicine: 'MEDS',
  school: 'SCHL',
  fuel: 'FUEL',
};

function randomBlock(len = 5) {
  const bytes = crypto.randomBytes(len);
  let out = '';
  for (let i = 0; i < len; i++) out += ALPHABET[bytes[i] % ALPHABET.length];
  return out;
}

/** Pick a prefix from the first allowed category, else GIFT. */
export function generateReference(allowedCategories = []) {
  const first = (allowedCategories[0] || '').toLowerCase();
  const prefix = CATEGORY_PREFIX[first] || 'GIFT';
  return `${prefix}-${randomBlock(5)}`;
}
