// db.js — thin wrapper that prefers better-sqlite3 and falls back to the
// built-in node:sqlite (Node >=22). Both expose prepare().run/get/all + exec.
// This means `npm install` succeeding is optional: the app still runs.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', 'data.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'schema.sql');

let db;
let driver;

try {
  const { default: Better } = await import('better-sqlite3');
  db = new Better(DB_PATH);
  db.pragma('journal_mode = WAL');
  driver = 'better-sqlite3';
} catch {
  // Fallback: Node's built-in SQLite (may require --experimental-sqlite on some builds).
  const { DatabaseSync } = await import('node:sqlite');
  db = new DatabaseSync(DB_PATH);
  driver = 'node:sqlite';
}

// Run the schema (idempotent — uses IF NOT EXISTS).
db.exec(fs.readFileSync(SCHEMA_PATH, 'utf8'));

// Normalise the two drivers behind one tiny API.
export const database = {
  driver,
  run(sql, params = []) {
    const stmt = db.prepare(sql);
    const info = stmt.run(...params);
    return { lastInsertRowid: Number(info.lastInsertRowid), changes: Number(info.changes) };
  },
  get(sql, params = []) {
    return db.prepare(sql).get(...params);
  },
  all(sql, params = []) {
    return db.prepare(sql).all(...params);
  },
  exec(sql) {
    return db.exec(sql);
  },
};

export default database;
