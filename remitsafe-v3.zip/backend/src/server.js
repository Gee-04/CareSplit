// server.js — proxy backend for RemitSafe (Restricted Remittance on Interledger)
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import db from './db.js';
import {
  createRestrictedRemittance, finalizeRemittance,
  getByReference, shopPurchase, purchaseHistory,
} from './flow.js';
import { handleWebhook } from './webhook.js';
import { isMock } from './opClient.js';
import { toDecimal, sub } from './money.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(cors());
app.use(express.json());

// ── Helpers ───────────────────────────────────────────────────────────────────
function hashPassword(password) {
  const salt = crypto.randomBytes(12).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}$${derived}`;
}

function verifyPassword(password, stored) {
  const [salt, derived] = stored.split('$');
  if (!salt || !derived) return false;
  const check = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(check, 'hex'), Buffer.from(derived, 'hex'));
}

function makeToken() {
  return crypto.randomBytes(24).toString('hex');
}

const money = (value, code, scale) => ({
  value,
  display: `${toDecimal(value, scale)} ${code}`,
  assetCode: code,
  assetScale: scale,
});

function formatRp(rp) {
  const remaining = sub(rp.received_amount_value || '0', rp.spent_amount_value || '0');
  return {
    id: rp.id,
    reference: rp.reference_number,
    status: rp.status,
    shopName: rp.shop_name || rp.shop_wallet,
    shopWallet: rp.shop_wallet,
    beneficiaryId: rp.beneficiary_id,
    allowedCategories: JSON.parse(rp.allowed_categories || '[]'),
    funded: money(rp.received_amount_value || '0', rp.asset_code, rp.asset_scale),
    spent: money(rp.spent_amount_value || '0', rp.asset_code, rp.asset_scale),
    remaining: money(remaining, rp.asset_code, rp.asset_scale),
    createdAt: rp.created_at || null,
    expiresAt: rp.expires_at,
  };
}

// ── Auth middleware ────────────────────────────────────────────────────────────
function requireAuth(req, res, next) {
  const hdr = req.header('Authorization') || '';
  const m = hdr.match(/^Bearer\s+(.+)$/i);
  const token = m ? m[1] : null;
  if (!token) return res.status(401).json({ error: 'Missing auth token.' });
  const row = db.get(
    `SELECT s.*, a.email, a.display_name, a.wallet_address
     FROM sessions s JOIN accounts a ON a.id = s.account_id
     WHERE s.token = ?`,
    [token],
  );
  if (!row) return res.status(401).json({ error: 'Invalid or expired token.' });
  req.account = {
    id: row.account_id,
    email: row.email,
    displayName: row.display_name,
    walletAddress: row.wallet_address,
  };
  next();
}

function requireStoreAuth(req, res, next) {
  const hdr = req.header('Authorization') || '';
  const m = hdr.match(/^Bearer\s+(.+)$/i);
  const token = m ? m[1] : null;
  if (!token) return res.status(401).json({ error: 'Missing store auth token.' });
  const row = db.get(
    `SELECT ss.*, sa.email, sa.store_name, sa.wallet_address
     FROM store_sessions ss JOIN store_accounts sa ON sa.id = ss.store_account_id
     WHERE ss.token = ?`,
    [token],
  );
  if (!row) return res.status(401).json({ error: 'Invalid or expired store token.' });
  req.store = {
    id: row.store_account_id,
    email: row.email,
    storeName: row.store_name,
    walletAddress: row.wallet_address,
  };
  next();
}

// ── Idempotency middleware ─────────────────────────────────────────────────────
function idempotent(req, res, next) {
  const key = req.header('Idempotency-Key');
  if (!key) return next();
  const hit = db.get(`SELECT response_json FROM idempotency_keys WHERE key=?`, [key]);
  if (hit?.response_json) {
    res.set('Idempotency-Replayed', 'true');
    return res.json(JSON.parse(hit.response_json));
  }
  const send = res.json.bind(res);
  res.json = (body) => {
    db.run(
      `INSERT OR IGNORE INTO idempotency_keys (key, endpoint, response_json) VALUES (?,?,?)`,
      [key, req.path, JSON.stringify(body)],
    );
    return send(body);
  };
  next();
}

// ── SENDER: register / login ──────────────────────────────────────────────────
app.post('/api/register', async (req, res) => {
  try {
    const { email, password, displayName, walletAddress } = req.body;
    if (!email || !password || !walletAddress)
      return res.status(400).json({ error: 'email, password and walletAddress are required.' });
    const ph = hashPassword(password);
    const r = db.run(
      `INSERT INTO accounts (email, password_hash, display_name, wallet_address) VALUES (?,?,?,?)`,
      [email, ph, displayName || '', walletAddress],
    );
    const token = makeToken();
    db.run(`INSERT INTO sessions (account_id, token) VALUES (?,?)`, [r.lastInsertRowid, token]);
    res.json({ token, account: { id: r.lastInsertRowid, email, displayName: displayName || '', walletAddress } });
  } catch (e) {
    if (e.message?.includes('UNIQUE')) return res.status(409).json({ error: 'Email already registered.' });
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'email and password required.' });
    const acc = db.get(`SELECT * FROM accounts WHERE email=?`, [email]);
    if (!acc || !verifyPassword(password, acc.password_hash))
      return res.status(401).json({ error: 'Invalid email or password.' });
    const token = makeToken();
    db.run(`INSERT INTO sessions (account_id, token) VALUES (?,?)`, [acc.id, token]);
    res.json({
      token,
      account: { id: acc.id, email: acc.email, displayName: acc.display_name, walletAddress: acc.wallet_address },
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/me', requireAuth, (req, res) => res.json(req.account));

// ── STORE: register / login ───────────────────────────────────────────────────
app.post('/api/store/register', async (req, res) => {
  try {
    const { email, password, storeName, walletAddress } = req.body;
    if (!email || !password || !storeName || !walletAddress)
      return res.status(400).json({ error: 'email, password, storeName and walletAddress are required.' });
    const ph = hashPassword(password);
    const r = db.run(
      `INSERT INTO store_accounts (email, password_hash, store_name, wallet_address) VALUES (?,?,?,?)`,
      [email, ph, storeName, walletAddress],
    );
    const token = makeToken();
    db.run(`INSERT INTO store_sessions (store_account_id, token) VALUES (?,?)`, [r.lastInsertRowid, token]);
    res.json({ token, store: { id: r.lastInsertRowid, email, storeName, walletAddress } });
  } catch (e) {
    if (e.message?.includes('UNIQUE')) return res.status(409).json({ error: 'Email or wallet address already registered.' });
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/store/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'email and password required.' });
    const acc = db.get(`SELECT * FROM store_accounts WHERE email=?`, [email]);
    if (!acc || !verifyPassword(password, acc.password_hash))
      return res.status(401).json({ error: 'Invalid email or password.' });
    const token = makeToken();
    db.run(`INSERT INTO store_sessions (store_account_id, token) VALUES (?,?)`, [acc.id, token]);
    res.json({ token, store: { id: acc.id, email: acc.email, storeName: acc.store_name, walletAddress: acc.wallet_address } });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/store/me', requireStoreAuth, (req, res) => res.json(req.store));

// ── STORE: view remittances destined for this store ───────────────────────────
app.get('/api/store/remittances', requireStoreAuth, (req, res) => {
  const rows = db.all(
    `SELECT * FROM restricted_payments WHERE shop_wallet=? ORDER BY id DESC`,
    [req.store.walletAddress],
  );
  const out = rows.map((rp) => ({
    ...formatRp(rp),
    history: purchaseHistory(rp.reference_number).slice(0, 10).map((p) => ({
      id: p.id,
      category: p.category,
      amount: money(p.amount_value, rp.asset_code, rp.asset_scale).display,
      status: p.status,
      rejectedReason: p.rejected_reason,
      createdAt: p.created_at,
    })),
  }));
  res.json(out);
});

// ── STORE: history for a specific reference (store-owned only) ────────────────
app.get('/api/store/remittances/:ref/history', requireStoreAuth, (req, res) => {
  const rp = db.get(`SELECT * FROM restricted_payments WHERE reference_number=?`, [req.params.ref]);
  if (!rp) return res.status(404).json({ error: 'Reference not found.' });
  if (rp.shop_wallet !== req.store.walletAddress)
    return res.status(403).json({ error: 'This reference does not belong to your store.' });
  const hist = purchaseHistory(req.params.ref).map((p) => ({
    id: p.id,
    category: p.category,
    amount: money(p.amount_value, rp.asset_code, rp.asset_scale).display,
    status: p.status,
    rejectedReason: p.rejected_reason,
    createdAt: p.created_at,
  }));
  res.json(hist);
});

// ── BENEFICIARIES ─────────────────────────────────────────────────────────────
app.get('/api/beneficiaries', requireAuth, (req, res) => {
  const rows = db.all(`SELECT * FROM beneficiaries WHERE account_id=? ORDER BY id DESC`, [req.account.id]);
  res.json(rows.map((r) => ({ id: r.id, name: r.name, walletAddress: r.wallet_address, createdAt: r.created_at })));
});

app.post('/api/beneficiaries', requireAuth, (req, res) => {
  const { name, walletAddress } = req.body;
  if (!name || !walletAddress) return res.status(400).json({ error: 'name and walletAddress required.' });
  const r = db.run(`INSERT INTO beneficiaries (account_id, name, wallet_address) VALUES (?,?,?)`, [req.account.id, name, walletAddress]);
  res.json({ id: r.lastInsertRowid, name, walletAddress });
});

app.delete('/api/beneficiaries/:id', requireAuth, (req, res) => {
  db.run(`DELETE FROM beneficiaries WHERE id=? AND account_id=?`, [Number(req.params.id), req.account.id]);
  res.json({ ok: true });
});

// ── SENDER: create remittances (multi-shop) ───────────────────────────────────
app.post('/api/remittances', requireAuth, idempotent, async (req, res) => {
  try {
    const { senderWallet, beneficiaryId, payments } = req.body;

    // Support both old single-payment shape and new multi-payment array.
    let paymentList = [];
    if (Array.isArray(payments) && payments.length > 0) {
      paymentList = payments;
    } else {
      // Legacy single-payment shape
      const { shopWallet, shopName, amount, allowedCategories, expiryDays } = req.body;
      if (!shopWallet || !amount) return res.status(400).json({ error: 'payments array (or shopWallet + amount) required.' });
      paymentList = [{ shopWallet, shopName, amount, allowedCategories, expiryDays }];
    }

    if (!senderWallet) return res.status(400).json({ error: 'senderWallet is required.' });

    const results = [];
    for (const p of paymentList) {
      if (!p.shopWallet || !p.amount) {
        return res.status(400).json({ error: 'Each payment must have shopWallet and amount.' });
      }

      // Look up if the shop wallet belongs to a registered store account.
      const storeAcc = db.get(`SELECT * FROM store_accounts WHERE wallet_address=?`, [p.shopWallet]);

      const out = await createRestrictedRemittance({
        senderWallet,
        shopWallet: p.shopWallet,
        shopName: p.shopName || storeAcc?.store_name || null,
        beneficiaryId: beneficiaryId || null,
        allowedCategories: p.allowedCategories || [],
        amountDecimal: String(p.amount),
        expiryDays: p.expiryDays || 30,
        accountId: req.account.id,
        shopAccountId: storeAcc?.id || null,
      });

      results.push({
        shopName: p.shopName || storeAcc?.store_name || p.shopWallet,
        shopWallet: p.shopWallet,
        reference: out.reference,
        quote: out.quote,
        redirectUrl: out.redirectUrl,
        ilp: out.ilp,
        sessionToken: out.sessionToken,
      });
    }

    // For the multi-payment flow, return all results and let the frontend
    // redirect to the first payment's consent URL. Additional consents chain
    // after the first webhook/callback resolves.
    res.json({ results, redirectUrl: results[0]?.redirectUrl });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── SENDER: list own remittances ──────────────────────────────────────────────
app.get('/api/remittances', requireAuth, (req, res) => {
  const rows = db.all(
    `SELECT rp.*, sa.store_name as registered_store_name
     FROM restricted_payments rp
     LEFT JOIN store_accounts sa ON sa.id = rp.shop_account_id
     WHERE rp.account_id = ?
     ORDER BY rp.id DESC`,
    [req.account.id],
  );
  res.json(rows.map((rp) => ({
    ...formatRp({ ...rp, shop_name: rp.registered_store_name || rp.shop_name }),
    history: purchaseHistory(rp.reference_number).slice(0, 5).map((p) => ({
      id: p.id,
      category: p.category,
      amount: money(p.amount_value, rp.asset_code, rp.asset_scale).display,
      status: p.status,
      rejectedReason: p.rejected_reason,
      createdAt: p.created_at,
    })),
  })));
});

// ── CALLBACK: after GNAP consent ──────────────────────────────────────────────
app.get('/api/callback', async (req, res) => {
  try {
    const { session, interact_ref } = req.query;
    await finalizeRemittance({ sessionToken: session, interactRef: interact_ref });
    res.redirect(`/?funded=${encodeURIComponent(session)}`);
  } catch (e) {
    res.status(500).send(`Finalization failed: ${e.message}`);
  }
});

// ── MOCK consent screen ───────────────────────────────────────────────────────
app.get('/mock-consent', (req, res) => {
  if (!isMock) return res.status(404).send('Not available outside MOCK_MODE.');
  const grant = req.query.grant || '';
  const row = db.get(`SELECT session_token FROM grant_sessions WHERE status='AWAITING_CONSENT' ORDER BY id DESC LIMIT 1`);
  const session = row?.session_token || '';
  res.send(`<!doctype html>
<meta charset=utf-8>
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Approve payment – RemitSafe</title>
<style>
  body{margin:0;min-height:100vh;display:grid;place-items:center;
       background:linear-gradient(135deg,#1B2CC1,#4A7CFF);font-family:system-ui}
  .box{background:#fff;border-radius:20px;padding:32px 28px;max-width:360px;
       width:90%;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.25)}
  .badge{display:inline-block;background:#EEF2FF;color:#4338CA;
         font:600 11px/1 monospace;padding:6px 12px;border-radius:999px;
         letter-spacing:.06em;margin-bottom:20px}
  h2{font-size:22px;color:#0F172A;margin:0 0 10px}
  p{font-size:14px;color:#475569;line-height:1.6;margin:0 0 24px}
  code{font:600 13px/1 monospace;color:#2251E8;background:#EEF2FF;
       padding:3px 7px;border-radius:6px}
  a{display:block;background:linear-gradient(135deg,#10B981,#059669);color:#fff;
    font:700 15px/1 system-ui;padding:15px;border-radius:12px;text-decoration:none}
  a:active{opacity:.85}
</style>
<div class="box">
  <div class="badge">MOCK · SENDER AUTH SERVER · GNAP</div>
  <h2>Approve this payment?</h2>
  <p>Grant <code>${grant}</code> is requesting permission to make one outgoing payment for the quoted amount from your Interledger wallet.</p>
  <a href="/api/callback?session=${session}&interact_ref=mock_${Date.now()}">✓ Approve &amp; Pay</a>
</div>`);
});

// ── PUBLIC: reference lookup ──────────────────────────────────────────────────
app.get('/api/references/:ref', (req, res) => {
  const rp = getByReference(req.params.ref);
  if (!rp) return res.status(404).json({ error: 'Reference not found.' });

  // Try to get the registered store name.
  const storeAcc = db.get(`SELECT store_name FROM store_accounts WHERE wallet_address=?`, [rp.shop_wallet]);

  const hist = purchaseHistory(rp.reference_number).map((p) => ({
    id: p.id,
    category: p.category,
    amount: money(p.amount_value, rp.asset_code, rp.asset_scale).display,
    status: p.status,
    rejectedReason: p.rejected_reason,
    createdAt: p.created_at,
  }));

  res.json({
    reference: rp.reference_number,
    status: rp.status,
    shopName: storeAcc?.store_name || rp.shop_name || rp.shop_wallet,
    shopWallet: rp.shop_wallet,
    beneficiaryId: rp.beneficiary_id,
    allowedCategories: rp.allowed_categories,
    funded: money(rp.received_amount_value, rp.asset_code, rp.asset_scale),
    spent: money(rp.spent_amount_value, rp.asset_code, rp.asset_scale),
    remaining: money(rp.remaining_value, rp.asset_code, rp.asset_scale),
    expiresAt: rp.expires_at,
    createdAt: rp.created_at,
    history: hist,
  });
});

// ── SHOP: charge against a reference ─────────────────────────────────────────
app.post('/api/purchases', idempotent, async (req, res) => {
  const { reference, amount, category } = req.body;
  if (!reference || !amount || !category)
    return res.status(400).json({ error: 'reference, amount and category are required.' });

  // Optional store auth: if a store token is present, verify wallet ownership.
  const hdr = req.header('Authorization') || '';
  const m = hdr.match(/^Bearer\s+(.+)$/i);
  if (m) {
    const storeRow = db.get(
      `SELECT ss.*, sa.wallet_address FROM store_sessions ss
       JOIN store_accounts sa ON sa.id = ss.store_account_id
       WHERE ss.token = ?`,
      [m[1]],
    );
    if (storeRow) {
      const rp = db.get(`SELECT shop_wallet FROM restricted_payments WHERE reference_number=?`, [reference]);
      if (rp && rp.shop_wallet !== storeRow.wallet_address)
        return res.status(403).json({ error: 'This reference does not belong to your store.' });
    }
  }

  const result = await shopPurchase({ reference, amountDecimal: String(amount), category });
  if (!result.ok) return res.status(409).json(result);
  res.json({
    ...result,
    spent: money(result.spent_value, result.asset_code, result.asset_scale).display,
    remaining: money(result.remaining_value, result.asset_code, result.asset_scale).display,
  });
});

// ── WEBHOOK ────────────────────────────────────────────────────────────────────
app.post('/api/webhooks', (req, res) => {
  const result = handleWebhook(req.body);
  res.status(200).json({ received: true, ...result });
});

// ── DEV: manual settle ────────────────────────────────────────────────────────
app.post('/api/dev/settle', (req, res) => {
  const rp = getByReference(req.body.reference);
  if (!rp) return res.status(404).json({ error: 'Reference not found.' });
  const result = handleWebhook({
    id: `dev_${Date.now()}`,
    type: 'incoming_payment.completed',
    data: { id: rp.incoming_payment_id, receivedAmount: { value: rp.incoming_amount_value } },
  });
  res.json(result);
});

app.get('/api/health', (_req, res) => res.json({ ok: true, mock: isMock, db: db.driver }));

// ── Static frontend ───────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, '..', '..', 'frontend')));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`RemitSafe proxy → http://localhost:${PORT}  [mock=${isMock}, db=${db.driver}]`);
});
