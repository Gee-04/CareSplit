-- ============================================================================
-- Restricted Remittance — Database Schema (SQLite dialect)
-- All money stored as STRING minor units (BigInt-safe), never float.
-- ============================================================================

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- ── Sender accounts ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS accounts (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  email          TEXT    NOT NULL UNIQUE,
  password_hash  TEXT    NOT NULL,
  display_name   TEXT,
  wallet_address TEXT    NOT NULL,
  created_at     TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- ── Store / institution accounts ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS store_accounts (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  email          TEXT    NOT NULL UNIQUE,
  password_hash  TEXT    NOT NULL,
  store_name     TEXT    NOT NULL,
  wallet_address TEXT    NOT NULL UNIQUE,
  created_at     TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- ── Sender sessions ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sessions (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id  INTEGER NOT NULL REFERENCES accounts(id),
  token       TEXT    NOT NULL UNIQUE,
  expires_at  TEXT,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- ── Store sessions ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS store_sessions (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  store_account_id INTEGER NOT NULL REFERENCES store_accounts(id),
  token            TEXT    NOT NULL UNIQUE,
  expires_at       TEXT,
  created_at       TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- ── Beneficiaries saved by senders ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS beneficiaries (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id     INTEGER NOT NULL REFERENCES accounts(id),
  name           TEXT    NOT NULL,
  wallet_address TEXT    NOT NULL,
  created_at     TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- ── Core restricted payment / voucher ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS restricted_payments (
  id                     INTEGER PRIMARY KEY AUTOINCREMENT,
  reference_number       TEXT    NOT NULL UNIQUE,
  incoming_payment_id    TEXT    UNIQUE,
  account_id             INTEGER REFERENCES accounts(id),
  shop_account_id        INTEGER REFERENCES store_accounts(id),
  sender_wallet          TEXT    NOT NULL,
  shop_wallet            TEXT    NOT NULL,
  shop_name              TEXT,
  beneficiary_id         TEXT,
  allowed_categories     TEXT    NOT NULL DEFAULT '[]',
  asset_code             TEXT    NOT NULL,
  asset_scale            INTEGER NOT NULL,
  incoming_amount_value  TEXT    NOT NULL,
  received_amount_value  TEXT    NOT NULL DEFAULT '0',
  spent_amount_value     TEXT    NOT NULL DEFAULT '0',
  status                 TEXT    NOT NULL DEFAULT 'PENDING_FUNDING'
        CHECK (status IN ('PENDING_FUNDING','FUNDED','PARTIALLY_SPENT','EXHAUSTED','EXPIRED','CANCELLED')),
  expires_at             TEXT,
  created_at             TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_rp_reference  ON restricted_payments(reference_number);
CREATE INDEX IF NOT EXISTS idx_rp_incoming   ON restricted_payments(incoming_payment_id);
CREATE INDEX IF NOT EXISTS idx_rp_account    ON restricted_payments(account_id);
CREATE INDEX IF NOT EXISTS idx_rp_shop_acct  ON restricted_payments(shop_account_id);
CREATE INDEX IF NOT EXISTS idx_rp_shop_wallet ON restricted_payments(shop_wallet);

-- ── GNAP consent bridge (step 6 → 7 → 8) ────────────────────────────────────
CREATE TABLE IF NOT EXISTS grant_sessions (
  id                     INTEGER PRIMARY KEY AUTOINCREMENT,
  session_token          TEXT    NOT NULL UNIQUE,
  restricted_payment_id  INTEGER REFERENCES restricted_payments(id),
  quote_id               TEXT    NOT NULL,
  sender_wallet          TEXT    NOT NULL,
  continue_uri           TEXT    NOT NULL,
  continue_token         TEXT    NOT NULL,
  nonce                  TEXT    NOT NULL,
  interact_ref           TEXT,
  status                 TEXT    NOT NULL DEFAULT 'AWAITING_CONSENT'
        CHECK (status IN ('AWAITING_CONSENT','CONSENTED','FINALIZED','REJECTED')),
  created_at             TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- ── Purchase history ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS purchase_history (
  id                     INTEGER PRIMARY KEY AUTOINCREMENT,
  restricted_payment_id  INTEGER NOT NULL REFERENCES restricted_payments(id),
  outgoing_payment_id    TEXT,
  category               TEXT    NOT NULL,
  amount_value           TEXT    NOT NULL,
  status                 TEXT    NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING','COMPLETED','REJECTED','FAILED')),
  rejected_reason        TEXT,
  created_at             TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ph_rp ON purchase_history(restricted_payment_id);

-- ── Webhook dedup ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS webhook_events (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  event_id    TEXT    UNIQUE,
  event_type  TEXT    NOT NULL,
  resource_id TEXT,
  payload     TEXT    NOT NULL,
  processed   INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- ── Client-side POST dedup ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS idempotency_keys (
  key           TEXT PRIMARY KEY,
  endpoint      TEXT NOT NULL,
  response_json TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
