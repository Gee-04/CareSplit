# Demo Script — "The ILP Magic" (≈90 seconds)

Goal: show a restriction the rails can't bypass, real cross-currency settlement,
and consent + webhooks — not a polling toy.

**Before you start:** `cd backend && npm start`, open `http://localhost:4000`.
Badge top-right reads **MOCK NETWORK** (flip to LIVE TEST NET with `MOCK_MODE=false`).

---

### 0:00 — The hook (one sentence)
> "Cash sent home gets diverted. We let a worker send money that can *only* buy
> groceries at *one* shop — enforced, not suggested."

### 0:12 — Send money (steps 1–6)
- **Send money** tab. Sender + shop wallet are pre-filled. Categories: leave
  **groceries** on, turn the rest off. Amount **50.00**. Click **Get quote & send**.
- Point at the **ILP corridor** that appears — this is the magic:
  > "35.50 **ZAR** debited on the left, 50.00 **KES** received on the right — a
  > real cross-currency quote with FX and fee, locked by Interledger. And here's
  > the actual **ILP packet address** and shared secret the payment routes over."

### 0:35 — Consent (steps 7–8)
- Click **Approve the debit at your bank**. The GNAP consent screen is the
  *sender's auth server*, not our app.
  > "Our backend never sees the bank password or holds the raw token — that's the
  > proxy pattern. We only get an `interact_ref` back."
- Click **Approve**. You land back with a **reference number** (e.g. `GROC-8YZHQ`),
  status **FUNDED & RESTRICTED**, packets flying across the corridor.
  > "Settlement was confirmed by a **webhook**, not polling — the #1 reason teams
  > fail here."

### 0:55 — Redeem at the shop till
- **Shop till** tab. Type the reference, **Look up**. Show the balance, allowed
  category, beneficiary id.
- Charge **30.00 / groceries** → succeeds, balance drops to **20.00**.
- Now charge **10.00 / alcohol** → **declined**:
  > "The metadata said groceries. Open Payments metadata is only *descriptive* —
  > so we enforce it in the proxy. That enforcement is the product."
- (Optional) Charge **30.00 / groceries** again → declined, over balance.

### 1:20 — The advanced flourish
- In a terminal, replay a purchase with the same idempotency key:
  ```bash
  KEY=demo-1
  curl -s -H "Idempotency-Key: $KEY" -X POST localhost:4000/api/purchases \
    -H 'Content-Type: application/json' \
    -d '{"reference":"GROC-8YZHQ","amount":"5.00","category":"groceries"}'
  curl -si -H "Idempotency-Key: $KEY" -X POST localhost:4000/api/purchases \
    -H 'Content-Type: application/json' \
    -d '{"reference":"GROC-8YZHQ","amount":"5.00","category":"groceries"}' | grep -i replayed
  ```
  > "Same key twice — charged once. `Idempotency-Replayed: true`. No double spend."

### 1:30 — Close (inclusion ladder)
> "**Access** — no bank needed. **Quality** — the sender controls where it's spent.
> **Welfare** — the money reaches groceries and medicine, every time. That's
> moving someone up the inclusion ladder, on open rails."

---

## If you have a live Rafiki / test wallet
Set `MOCK_MODE=false`, run `ngrok http 4000`, point Rafiki's webhook at
`https://<id>.ngrok.app/api/webhooks`. The same demo runs against real
`incoming_payment.completed` events — the corridor and reference flow are identical.

## One-liners judges tend to ask
- *"Is the restriction on-chain?"* — No. ILP metadata is descriptive; we enforce
  category + balance in the proxy. Deliberate and honest.
- *"Why a proxy?"* — GNAP tokens and continue-tokens stay server-side; the browser
  never holds them. BigInt `assetScale` math also stays server-side.
- *"Polling?"* — No. Webhook-driven settlement confirmation.
