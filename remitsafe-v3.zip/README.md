# Restricted Remittance — Open Payments / Interledger

Send money home that can **only** be spent on what it's meant for — groceries,
medicine, school fees — at **one named shop**. A migrant worker (sender) funds a
restricted "voucher" at a shop's wallet; the beneficiary quotes a human-readable
**reference number** at the till; the till releases funds only within the
allowed categories and remaining balance.

Built on **Open Payments** with **GNAP** consent grants and **webhook-confirmed**
settlement, using the mandated **proxy-backend** pattern.

---

## Why this matters (inclusion ladder)

- **Access** → anyone with a wallet address can receive, no bank account needed.
- **Quality** → the sender controls *where* and *on what* — safer than cash, no 8% remittance fee model baked in.
- **Welfare** → funds can't be diverted; they reach groceries/medicine as intended.

**Honest, important point for judges:** Open Payments `metadata` is *descriptive*,
not *enforced* by the ILP network. The restriction ("groceries only") is enforced
**in our proxy backend** — category + balance checks live in `flow.js`. That
enforcement is the product, and it's a deliberate architectural choice, not a gap.

---

## Architecture (proxy-backend pattern)

```
 React SPA (no build)          Node/Express proxy            Open Payments / Rafiki
 ─ frontend/index.html  ──▶    ─ holds GNAP tokens   ──▶     ─ sender + shop wallets
   never sees tokens             ─ BigInt assetScale          ─ auth + resource servers
                                 ─ SQLite source of truth
                                 ─ webhook listener  ◀──────  settlement events
```

- **Frontend** never receives a GNAP token. It only talks to our REST API.
- **Backend** stores Rafiki access/continue tokens, does all BigInt minor-unit math, enforces restrictions, and listens for webhooks.
- **SQLite** is the source of truth for the spendable balance (see `schema.sql`).

---

## Quickstart (mock mode — no wallets, no Rafiki)

```bash
cd backend
npm install            # better-sqlite3 is optional; node:sqlite is the fallback
cp .env.example .env   # MOCK_MODE=true by default
npm start              # → http://localhost:4000
```

Open **http://localhost:4000**:

1. **Send money** → pick categories → *Get quote & send* (steps 1–6).
2. *Approve the debit at your bank* → mock consent screen → *Approve* (steps 7–8).
3. You return with a **reference number**, fully funded.
4. **Shop till** tab → enter the reference → charge groceries (allowed) and try
   alcohol (blocked).

> Mock mode is fully offline and deterministic — perfect for Day-1 demos and CI.
> No `node_modules` for SQLite required: if `better-sqlite3` won't compile, the
> app automatically uses Node's built-in `node:sqlite`.

---

## The 8-step canonical flow → where it lives

| Step | What | Code |
|------|------|------|
| 1 Discovery | resolve sender + shop wallets | `flow.js` → `walletAddress.get` |
| 2 Incoming grant | non-interactive, shop's auth server | `flow.js` → `grant.request` |
| 3 **Incoming payment + metadata** | restriction (beneficiary, categories, expiry) | `flow.js` → `incomingPayment.create` |
| 4 Quote grant | non-interactive, sender's auth server | `flow.js` → `grant.request` |
| 5 Quote | lock FX + fees | `flow.js` → `quote.create` |
| 6 **Outgoing grant (interactive)** | GNAP redirect for consent | `flow.js` → `grant.request` + `interact` |
| 7 Continuation | exchange `interact_ref` for token | `flow.js` → `grant.continue` (via `/api/callback`) |
| 8 Outgoing payment | execute; settle out-of-band | `flow.js` → `outgoingPayment.create` |

Settlement is confirmed by **webhook**, never by polling — see `webhook.js`.

---

## Going live (real Open Payments test network)

1. Create sender + shop wallet addresses on a test environment
   (e.g. the Interledger test wallet / a Rafiki instance).
2. Generate an Ed25519 key for this app and register the public key on its wallet:
   ```bash
   mkdir -p backend/keys
   openssl genpkey -algorithm Ed25519 -out backend/keys/private.key
   ```
3. Fill `.env`:
   ```
   MOCK_MODE=false
   OP_CLIENT_WALLET_URL=https://your-test-host/your-app
   OP_KEY_ID=<key id registered on that wallet>
   OP_PRIVATE_KEY_PATH=./keys/private.key
   ```
4. Expose the webhook to Rafiki with ngrok and point Rafiki's webhook URL at it:
   ```bash
   ngrok http 4000
   # Rafiki webhook target → https://<ngrok-id>.ngrok.app/api/webhooks
   ```

`incoming_payment.completed` events then drive the balance automatically.

---

## REST API

| Method | Path | Purpose |
|--------|------|---------|
| POST | `/api/remittances` | run steps 1–6, return reference + consent `redirectUrl` |
| GET  | `/api/callback` | sender's auth server returns here (steps 7–8) |
| GET  | `/api/references/:ref` | balance, allowed categories, history |
| POST | `/api/purchases` | redeem at the till (category + balance enforced) |
| POST | `/api/webhooks` | Rafiki settlement events (idempotent) |
| POST | `/api/dev/settle` | dev helper: fire a settlement event by reference |
| GET  | `/api/health` | mode + db driver |

`/api/remittances` and `/api/purchases` accept an **`Idempotency-Key`** header;
a retried request returns the stored response (`Idempotency-Replayed: true`)
instead of charging twice.

---

## Money handling

All amounts on the wire are **strings of minor units** (BigInt-safe). `money.js`
converts: `toMinor("50.00", 2) === "5000"`, `toDecimal("5000", 2) === "50.00"`.
Never a JavaScript float.

## Files

```
backend/
  schema.sql        database schema (users, restricted_payments, grant_sessions,
                    purchase_history, webhook_events, idempotency_keys)
  src/
    server.js       Express routes, idempotency middleware, static host
    flow.js         the 8-step flow + shop redemption + restriction enforcement
    opClient.js     real SDK client + mock client (same surface)
    webhook.js      idempotent settlement handler
    money.js        BigInt / assetScale helpers
    reference.js    human-readable reference numbers (GROC-XXXXX)
    db.js           better-sqlite3 → node:sqlite fallback
frontend/
  index.html        no-build React SPA (sender + shop till + ILP packet view)
DEMO_SCRIPT.md      90-second judge demo
```
