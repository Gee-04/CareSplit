-- ============================================================================
-- Restricted Remittance — Database Schema (SQLite dialect)
-- ----------------------------------------------------------------------------
-- All money is stored as a STRING of MINOR UNITS (BigInt-safe), never a float.
-- e.g. 50.00 ZAR at assetScale 2  ->  "5000"
-- The grant_sessions table is the bridge across the interactive GNAP consent
-- gap: it survives the redirect to the sender's auth server (step 6) and lets
-- the callback (step 7) finish the grant and create the payment (step 8).
-- ============================================================================

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- Senders (migrant workers), shops (receivers), beneficiaries (redeemers).
CREATE TABLE IF NOT EXISTS users (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  wallet_address  TEXT    NOT NULL UNIQUE,          -- e.g. https://wallet.example/alice
  display_name    TEXT    NOT NULL,
  role            TEXT    NOT NULL CHECK (role IN ('sender','shop','beneficiary')),
  created_at      TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Accounts: simple parent/sender accounts with password hash and linked wallet
CREATE TABLE IF NOT EXISTS accounts (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  email         TEXT    NOT NULL UNIQUE,
  password_hash TEXT    NOT NULL,
  display_name  TEXT,
  wallet_address TEXT   NOT NULL,
  created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Sessions: simple bearer tokens for the frontend to authenticate API requests.
CREATE TABLE IF NOT EXISTS sessions (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id  INTEGER NOT NULL REFERENCES accounts(id),
  token       TEXT    NOT NULL UNIQUE,
  expires_at  TEXT,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Beneficiaries that a parent adds (name + wallet address)
CREATE TABLE IF NOT EXISTS beneficiaries (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id    INTEGER NOT NULL REFERENCES accounts(id),
  name          TEXT    NOT NULL,
  wallet_address TEXT   NOT NULL,
  created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- One row per remittance. This is the restricted "voucher" and the source of
-- truth for the spendable balance and the category restriction.
CREATE TABLE IF NOT EXISTS restricted_payments (
  id                     INTEGER PRIMARY KEY AUTOINCREMENT,
  reference_number       TEXT    NOT NULL UNIQUE,   -- human-readable, e.g. GROC-7K2M9
  incoming_payment_id    TEXT    UNIQUE,            -- Open Payments incoming payment URL
  sender_wallet          TEXT    NOT NULL,
  shop_wallet            TEXT    NOT NULL,
  beneficiary_id         TEXT,                      -- who may redeem at the shop
  allowed_categories     TEXT    NOT NULL DEFAULT '[]',  -- JSON array, e.g. ["groceries"]
  asset_code             TEXT    NOT NULL,          -- e.g. ZAR
  asset_scale            INTEGER NOT NULL,          -- e.g. 2
  incoming_amount_value  TEXT    NOT NULL,          -- minor units, BigInt string
  received_amount_value  TEXT    NOT NULL DEFAULT '0', -- confirmed by webhook
  spent_amount_value     TEXT    NOT NULL DEFAULT '0', -- sum of completed purchases
  status                 TEXT    NOT NULL DEFAULT 'PENDING_FUNDING'
        CHECK (status IN ('PENDING_FUNDING','FUNDED','PARTIALLY_SPENT','EXHAUSTED','EXPIRED','CANCELLED')),
  expires_at             TEXT,
  created_at             TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_rp_reference ON restricted_payments(reference_number);
CREATE INDEX IF NOT EXISTS idx_rp_incoming  ON restricted_payments(incoming_payment_id);

-- Bridges the interactive GNAP consent gap (step 6 -> step 7 -> step 8).
-- continue_token is a server-only secret and MUST NEVER reach the frontend.
CREATE TABLE IF NOT EXISTS grant_sessions (
  id                     INTEGER PRIMARY KEY AUTOINCREMENT,
  session_token          TEXT    NOT NULL UNIQUE,   -- our opaque id, placed in the redirect URL
  restricted_payment_id  INTEGER REFERENCES restricted_payments(id),
  quote_id               TEXT    NOT NULL,
  sender_wallet          TEXT    NOT NULL,
  continue_uri           TEXT    NOT NULL,          -- GNAP continuation endpoint
  continue_token         TEXT    NOT NULL,          -- GNAP continue access token (SECRET)
  nonce                  TEXT    NOT NULL,          -- to verify the interact hash on callback
  interact_ref           TEXT,                      -- filled in by the callback
  status                 TEXT    NOT NULL DEFAULT 'AWAITING_CONSENT'
        CHECK (status IN ('AWAITING_CONSENT','CONSENTED','FINALIZED','REJECTED')),
  created_at             TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Each redemption made at the shop against a reference number.
CREATE TABLE IF NOT EXISTS purchase_history (
  id                     INTEGER PRIMARY KEY AUTOINCREMENT,
  restricted_payment_id  INTEGER NOT NULL REFERENCES restricted_payments(id),
  outgoing_payment_id    TEXT,                      -- set when a real OP outgoing payment is made
  category               TEXT    NOT NULL,
  amount_value           TEXT    NOT NULL,          -- minor units, BigInt string
  status                 TEXT    NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING','COMPLETED','REJECTED','FAILED')),
  rejected_reason        TEXT,
  created_at             TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ph_rp ON purchase_history(restricted_payment_id);

-- Webhook events from Rafiki. event_id is unique so re-delivered events are
-- processed exactly once (idempotent settlement).
CREATE TABLE IF NOT EXISTS webhook_events (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  event_id      TEXT    UNIQUE,                     -- Rafiki event id (dedupe key)
  event_type    TEXT    NOT NULL,                   -- e.g. incoming_payment.completed
  resource_id   TEXT,                               -- the payment id the event concerns
  payload       TEXT    NOT NULL,                   -- raw JSON body
  processed     INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Dedupe our own client POSTs (/api/remittances, /api/purchases) via the
-- Idempotency-Key header. A retried request returns the stored response.
CREATE TABLE IF NOT EXISTS idempotency_keys (
  key           TEXT PRIMARY KEY,
  endpoint      TEXT NOT NULL,
  response_json TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
